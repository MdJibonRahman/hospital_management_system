-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2026 at 02:41 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_management_pro`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `appointment_at` datetime NOT NULL,
  `status` enum('scheduled','checked_in','completed','cancelled') NOT NULL DEFAULT 'scheduled',
  `reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `patient_id`, `doctor_id`, `appointment_at`, `status`, `reason`, `created_at`) VALUES
(1, 1, 1, '2026-06-23 09:00:00', 'scheduled', 'Blood pressure follow-up', '2026-06-23 12:18:25'),
(2, 2, 2, '2026-06-23 10:30:00', 'checked_in', 'Fever and body ache', '2026-06-23 12:18:25'),
(3, 3, 3, '2026-06-23 12:00:00', 'completed', 'Child vaccination', '2026-06-23 12:18:25'),
(4, 4, 4, '2026-06-24 15:00:00', 'scheduled', 'Knee pain', '2026-06-23 12:18:25'),
(5, 5, 2, '2026-06-22 11:00:00', 'scheduled', 'Consultation', '2026-06-23 12:18:25'),
(6, 1, 1, '2026-06-25 16:00:00', 'scheduled', 'Routine checkup', '2026-06-23 12:18:25'),
(7, 3, 2, '2026-06-26 13:30:00', 'scheduled', 'Follow-up', '2026-06-23 12:18:25');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `doctors` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `specialty` varchar(120) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `name`, `specialty`, `status`, `created_at`) VALUES
(1, 'Dr. Samia Karim', 'Cardiology', 'active', '2026-06-23 12:18:25'),
(2, 'Dr. Tanvir Ahmed', 'Medicine', 'active', '2026-06-23 12:18:25'),
(3, 'Dr. Rubaiyat Chowdhury', 'Pediatrics', 'active', '2026-06-23 12:18:25'),
(4, 'Dr. Mehedi Hasan', 'Orthopedics', 'active', '2026-06-23 12:18:25');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `invoice_date` date NOT NULL,
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status` enum('invoice','paid','partial') NOT NULL DEFAULT 'invoice'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `patient_id`, `invoice_date`, `total_amount`, `paid_amount`, `status`) VALUES
(1, 1, '2026-01-12', 2400.00, 2400.00, 'paid'),
(2, 2, '2026-02-04', 1850.00, 1400.00, 'partial'),
(3, 3, '2026-03-18', 4200.00, 4200.00, 'paid'),
(4, 4, '2026-04-09', 1550.00, 900.00, 'partial'),
(5, 5, '2026-05-21', 3100.00, 3100.00, 'paid'),
(6, 1, '2026-06-02', 2200.00, 1600.00, 'partial'),
(7, 2, '2026-06-16', 1700.00, 1700.00, 'paid');

-- --------------------------------------------------------

--
-- Table structure for table `medicines`
--

CREATE TABLE `medicines` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `stock_quantity` int(11) NOT NULL DEFAULT 0,
  `reorder_level` int(11) NOT NULL DEFAULT 10,
  `unit_price` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicines`
--

INSERT INTO `medicines` (`id`, `name`, `stock_quantity`, `reorder_level`, `unit_price`) VALUES
(1, 'Paracetamol 500mg', 42, 25, 0.30),
(2, 'Amoxicillin 250mg', 9, 20, 1.15),
(3, 'Salbutamol Inhaler', 7, 12, 8.50),
(4, 'Metformin 500mg', 38, 15, 0.45),
(5, 'Omeprazole 20mg', 11, 18, 0.70),
(6, 'Cetirizine 10mg', 75, 20, 0.20);

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `gender` enum('male','female','other') DEFAULT 'other',
  `date_of_birth` date DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `name`, `phone`, `gender`, `date_of_birth`, `status`, `created_at`) VALUES
(1, 'Amina Rahman', '+8801711000001', 'female', '1991-04-14', 'active', '2026-06-23 12:18:25'),
(2, 'Karim Uddin', '+8801711000002', 'male', '1984-09-02', 'active', '2026-06-23 12:18:25'),
(3, 'Nusrat Jahan', '+8801711000003', 'female', '2000-11-24', 'active', '2026-06-23 12:18:25'),
(4, 'Hasan Mahmud', '+8801711000004', 'male', '1977-01-20', 'active', '2026-06-23 12:18:25'),
(5, 'Farzana Akter', '+8801711000005', 'female', '1995-07-09', 'active', '2026-06-23 12:18:25'),
(6, 'Rafiq Islam', '+8801711000006', 'male', '1968-03-18', 'inactive', '2026-06-23 12:18:25');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy`
--

CREATE TABLE `pharmacy` (
  `id` int(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `medicine` varchar(255) NOT NULL,
  `date_and_time` datetime(6) NOT NULL,
  `total_money` int(20) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_appointment_at` (`appointment_at`),
  ADD KEY `idx_doctor_slot` (`doctor_id`,`appointment_at`),
  ADD KEY `fk_appointments_patient` (`patient_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_invoices_patient` (`patient_id`);

--
-- Indexes for table `medicines`
--
ALTER TABLE `medicines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pharmacy`
--
ALTER TABLE `pharmacy`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `medicines`
--
ALTER TABLE `medicines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `pharmacy`
--
ALTER TABLE `pharmacy`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `fk_appointments_doctor` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_appointments_patient` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `invoices`
--
ALTER TABLE `invoices`
  ADD CONSTRAINT `fk_invoices_patient` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
