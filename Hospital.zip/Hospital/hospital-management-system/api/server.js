import cors from "cors";
import dotenv from "dotenv";
import express from "express";
import mysql from "mysql2/promise";

dotenv.config();

const app = express();
const port = Number(process.env.PORT || 5000);

app.use(cors());
app.use(express.json());

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "hospital_management_pro",
  waitForConnections: true,
  connectionLimit: 10
});

const allowedStatuses = new Set(["scheduled", "checked_in", "completed", "cancelled"]);

app.get("/api/overview", async (_request, response, next) => {
  try {
    const [[activePatientsRows], [todayRows], [monthlyRows], [lowStockRows]] = await Promise.all([
      pool.query("SELECT COUNT(*) AS total FROM patients WHERE status = 'active'"),
      pool.query(
        `SELECT status, COUNT(*) AS total
         FROM appointments
         WHERE DATE(appointment_at) = CURDATE()
         GROUP BY status`
      ),
      pool.query(
        `SELECT COALESCE(SUM(paid_amount), 0) AS total
         FROM invoices
         WHERE invoice_date >= DATE_FORMAT(CURDATE(), '%Y-%m-01')`
      ),
      pool.query(
        `SELECT id, name, stock_quantity, reorder_level
         FROM medicines
         WHERE stock_quantity <= reorder_level
         ORDER BY stock_quantity ASC
         LIMIT 8`
      )
    ]);

    const byStatus = Object.fromEntries([...allowedStatuses].map((status) => [status, 0]));
    for (const row of todayRows) byStatus[row.status] = Number(row.total);

    response.json({
      activePatients: Number(activePatientsRows[0].total),
      todayAppointments: {
        total: Object.values(byStatus).reduce((sum, count) => sum + Number(count), 0),
        byStatus
      },
      monthlyRevenue: Number(monthlyRows[0].total),
      lowStockMedicines: lowStockRows
    });
  } catch (error) {
    next(error);
  }
});

app.get("/api/patients", async (_request, response, next) => {
  try {
    const [rows] = await pool.query(
      "SELECT id, name, phone, status FROM patients WHERE status = 'active' ORDER BY name"
    );
    response.json(rows);
  } catch (error) {
    next(error);
  }
});

app.get("/api/doctors", async (_request, response, next) => {
  try {
    const [rows] = await pool.query(
      "SELECT id, name, specialty FROM doctors WHERE status = 'active' ORDER BY name"
    );
    response.json(rows);
  } catch (error) {
    next(error);
  }
});

app.get("/api/appointments", async (request, response, next) => {
  try {
    const search = `%${String(request.query.search || "").trim()}%`;
    const [rows] = await pool.query(
      `SELECT
        a.id,
        a.appointment_at,
        a.status,
        a.reason,
        p.name AS patient_name,
        d.name AS doctor_name
       FROM appointments a
       JOIN patients p ON p.id = a.patient_id
       JOIN doctors d ON d.id = a.doctor_id
       WHERE p.name LIKE ?
       ORDER BY a.appointment_at DESC`,
      [search]
    );
    response.json(rows);
  } catch (error) {
    next(error);
  }
});

app.post("/api/appointments", async (request, response, next) => {
  try {
    const { patient_id, doctor_id, appointment_date, appointment_time, reason } = request.body;
    if (!patient_id || !doctor_id || !appointment_date || !appointment_time) {
      return response.status(400).json({ message: "Patient, doctor, date, and time are required." });
    }

    const appointmentAt = `${appointment_date} ${appointment_time}:00`;
    const [conflicts] = await pool.query(
      `SELECT id
       FROM appointments
       WHERE doctor_id = ?
         AND appointment_at = ?
         AND status IN ('scheduled', 'checked_in')
       LIMIT 1`,
      [doctor_id, appointmentAt]
    );

    if (conflicts.length > 0) {
      return response.status(409).json({
        message: "This doctor already has an appointment at that date and time. Choose another slot."
      });
    }

    const [result] = await pool.query(
      `INSERT INTO appointments (patient_id, doctor_id, appointment_at, status, reason)
       VALUES (?, ?, ?, 'scheduled', ?)`,
      [patient_id, doctor_id, appointmentAt, reason || null]
    );

    response.status(201).json({ id: result.insertId });
  } catch (error) {
    next(error);
  }
});

app.patch("/api/appointments/:id/status", async (request, response, next) => {
  try {
    const { status } = request.body;
    if (!allowedStatuses.has(status)) {
      return response.status(400).json({ message: "Invalid appointment status." });
    }

    const [result] = await pool.query(
      "UPDATE appointments SET status = ? WHERE id = ?",
      [status, request.params.id]
    );

    if (result.affectedRows === 0) {
      return response.status(404).json({ message: "Appointment not found." });
    }

    response.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

app.get("/api/reports/revenue", async (request, response, next) => {
  try {
    const from = request.query.from || `${new Date().getFullYear()}-01-01`;
    const to = request.query.to || new Date().toISOString().slice(0, 10);
    const [rows] = await pool.query(
      `SELECT
        DATE_FORMAT(invoice_date, '%Y-%m') AS month,
        COALESCE(SUM(total_amount), 0) AS invoice_total,
        COALESCE(SUM(paid_amount), 0) AS paid_total
       FROM invoices
       WHERE invoice_date BETWEEN ? AND ?
       GROUP BY DATE_FORMAT(invoice_date, '%Y-%m')
       ORDER BY month`,
      [from, to]
    );

    response.json(
      rows.map((row) => ({
        month: row.month,
        invoice_total: Number(row.invoice_total),
        paid_total: Number(row.paid_total)
      }))
    );
  } catch (error) {
    next(error);
  }
});

app.use((error, _request, response, _next) => {
  console.error(error);
  response.status(500).json({
    message: "Server error. Check the API terminal and database connection."
  });
});

app.listen(port, () => {
  console.log(`Hospital Management Pro API running on http://localhost:${port}`);
});
