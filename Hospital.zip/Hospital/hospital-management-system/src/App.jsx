import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Activity,
  AlertTriangle,
  CalendarDays,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  CircleDollarSign,
  Loader2,
  Plus,
  RefreshCw,
  Search,
  Stethoscope,
  Users
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";

const API_BASE = import.meta.env.VITE_API_URL || "";
const PAGE_SIZE = 6;
const STATUS_OPTIONS = ["scheduled", "checked_in", "completed", "cancelled"];

function App() {
  const today = new Date().toISOString().slice(0, 10);
  const firstOfYear = `${new Date().getFullYear()}-01-01`;
  const [overview, setOverview] = useState(null);
  const [appointments, setAppointments] = useState([]);
  const [patients, setPatients] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [revenue, setRevenue] = useState([]);
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState({ key: "appointment_at", direction: "asc" });
  const [page, setPage] = useState(1);
  const [revenueRange, setRevenueRange] = useState({ from: firstOfYear, to: today });
  const [loading, setLoading] = useState({
    overview: true,
    appointments: true,
    revenue: true,
    people: true
  });
  const [error, setError] = useState("");
  const [bookingError, setBookingError] = useState("");
  const [savingAppointment, setSavingAppointment] = useState(false);
  const [updatingStatusId, setUpdatingStatusId] = useState(null);
  const [form, setForm] = useState({
    patient_id: "",
    doctor_id: "",
    appointment_date: today,
    appointment_time: "09:00",
    reason: ""
  });

  async function request(path, options) {
    const response = await fetch(`${API_BASE}${path}`, {
      headers: { "Content-Type": "application/json" },
      ...options
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(data.message || "The request could not be completed.");
    }
    return data;
  }

  async function loadOverview() {
    setLoading((current) => ({ ...current, overview: true }));
    try {
      setOverview(await request("/api/overview"));
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading((current) => ({ ...current, overview: false }));
    }
  }

  async function loadAppointments() {
    setLoading((current) => ({ ...current, appointments: true }));
    try {
      const data = await request(`/api/appointments?search=${encodeURIComponent(search)}`);
      setAppointments(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading((current) => ({ ...current, appointments: false }));
    }
  }

  async function loadPeople() {
    setLoading((current) => ({ ...current, people: true }));
    try {
      const [patientsData, doctorsData] = await Promise.all([
        request("/api/patients"),
        request("/api/doctors")
      ]);
      setPatients(patientsData);
      setDoctors(doctorsData);
      setForm((current) => ({
        ...current,
        patient_id: current.patient_id || patientsData[0]?.id || "",
        doctor_id: current.doctor_id || doctorsData[0]?.id || ""
      }));
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading((current) => ({ ...current, people: false }));
    }
  }

  async function loadRevenue() {
    setLoading((current) => ({ ...current, revenue: true }));
    try {
      const data = await request(
        `/api/reports/revenue?from=${revenueRange.from}&to=${revenueRange.to}`
      );
      setRevenue(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading((current) => ({ ...current, revenue: false }));
    }
  }

  useEffect(() => {
    loadOverview();
    loadPeople();
  }, []);

  useEffect(() => {
    const timeout = setTimeout(() => {
      loadAppointments();
      setPage(1);
    }, 250);
    return () => clearTimeout(timeout);
  }, [search]);

  useEffect(() => {
    loadRevenue();
  }, [revenueRange.from, revenueRange.to]);

  const sortedAppointments = useMemo(() => {
    return [...appointments].sort((a, b) => {
      const first = a[sort.key] ?? "";
      const second = b[sort.key] ?? "";
      const result = String(first).localeCompare(String(second), undefined, {
        numeric: true,
        sensitivity: "base"
      });
      return sort.direction === "asc" ? result : -result;
    });
  }, [appointments, sort]);

  const totalPages = Math.max(1, Math.ceil(sortedAppointments.length / PAGE_SIZE));
  const pageAppointments = sortedAppointments.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  function changeSort(key) {
    setSort((current) => ({
      key,
      direction: current.key === key && current.direction === "asc" ? "desc" : "asc"
    }));
  }

  async function updateStatus(appointmentId, status) {
    setUpdatingStatusId(appointmentId);
    setError("");
    try {
      await request(`/api/appointments/${appointmentId}/status`, {
        method: "PATCH",
        body: JSON.stringify({ status })
      });
      await Promise.all([loadAppointments(), loadOverview()]);
    } catch (err) {
      setError(err.message);
    } finally {
      setUpdatingStatusId(null);
    }
  }

  async function bookAppointment(event) {
    event.preventDefault();
    setSavingAppointment(true);
    setBookingError("");
    setError("");
    try {
      await request("/api/appointments", {
        method: "POST",
        body: JSON.stringify(form)
      });
      setForm((current) => ({ ...current, reason: "" }));
      await Promise.all([loadAppointments(), loadOverview()]);
    } catch (err) {
      setBookingError(err.message);
    } finally {
      setSavingAppointment(false);
    }
  }

  return (
    <main className="app-shell">
      <style>{styles}</style>
      <header className="topbar">
        <div>
          <p className="eyebrow">Hospital Management System</p>
          <h1>Clinical operations dashboard</h1>
        </div>
        <button
          className="icon-button"
          type="button"
          title="Refresh dashboard"
          onClick={() => {
            loadOverview();
            loadAppointments();
            loadRevenue();
          }}
        >
          <RefreshCw size={18} />
        </button>
      </header>

      {error && <div className="alert">{error}</div>}

      <section className="metrics-grid">
        <MetricCard
          title="Active patients"
          value={overview?.activePatients}
          icon={<Users size={20} />}
          loading={loading.overview}
          empty={overview && overview.activePatients === 0}
        />
        <MetricCard
          title="Today's appointments"
          value={overview?.todayAppointments?.total}
          subtext={overview ? statusSummary(overview.todayAppointments?.byStatus) : ""}
          icon={<CalendarDays size={20} />}
          loading={loading.overview}
          empty={overview && overview.todayAppointments?.total === 0}
        />
        <MetricCard
          title="Monthly revenue"
          value={formatMoney(overview?.monthlyRevenue)}
          icon={<CircleDollarSign size={20} />}
          loading={loading.overview}
          empty={overview && Number(overview.monthlyRevenue) === 0}
        />
        <MetricCard
          title="Low-stock medicine"
          value={overview?.lowStockMedicines?.length}
          subtext={overview?.lowStockMedicines?.slice(0, 2).map((item) => item.name).join(", ")}
          icon={<AlertTriangle size={20} />}
          loading={loading.overview}
          empty={overview && overview.lowStockMedicines?.length === 0}
        />
      </section>

      <section className="work-grid">
        <Panel title="Appointments" right={<SearchBox value={search} onChange={setSearch} />}>
          {loading.appointments ? (
            <Spinner label="Loading appointments" />
          ) : appointments.length === 0 ? (
            <EmptyState title="No appointments found" text="Try a different patient name." />
          ) : (
            <>
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <SortableTh label="Patient" column="patient_name" sort={sort} onSort={changeSort} />
                      <SortableTh label="Doctor" column="doctor_name" sort={sort} onSort={changeSort} />
                      <SortableTh label="Date/time" column="appointment_at" sort={sort} onSort={changeSort} />
                      <SortableTh label="Status" column="status" sort={sort} onSort={changeSort} />
                      <th>Update</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pageAppointments.map((appointment) => (
                      <tr key={appointment.id}>
                        <td>
                          <strong>{appointment.patient_name}</strong>
                          <span>{appointment.reason || "General visit"}</span>
                        </td>
                        <td>{appointment.doctor_name}</td>
                        <td>{formatDateTime(appointment.appointment_at)}</td>
                        <td>
                          <StatusBadge status={appointment.status} />
                        </td>
                        <td>
                          <select
                            value={appointment.status}
                            disabled={updatingStatusId === appointment.id}
                            onChange={(event) => updateStatus(appointment.id, event.target.value)}
                            aria-label={`Update ${appointment.patient_name} status`}
                          >
                            {STATUS_OPTIONS.map((status) => (
                              <option value={status} key={status}>
                                {labelStatus(status)}
                              </option>
                            ))}
                          </select>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="pagination">
                <button
                  className="icon-button"
                  type="button"
                  title="Previous page"
                  disabled={page === 1}
                  onClick={() => setPage((current) => Math.max(1, current - 1))}
                >
                  <ChevronLeft size={18} />
                </button>
                <span>
                  Page {page} of {totalPages}
                </span>
                <button
                  className="icon-button"
                  type="button"
                  title="Next page"
                  disabled={page === totalPages}
                  onClick={() => setPage((current) => Math.min(totalPages, current + 1))}
                >
                  <ChevronRight size={18} />
                </button>
              </div>
            </>
          )}
        </Panel>

        <Panel title="Book appointment" icon={<Plus size={18} />}>
          {loading.people ? (
            <Spinner label="Loading form data" />
          ) : patients.length === 0 || doctors.length === 0 ? (
            <EmptyState title="Booking unavailable" text="Add patients and doctors in the database first." />
          ) : (
            <form className="booking-form" onSubmit={bookAppointment}>
              <label>
                Patient
                <select
                  value={form.patient_id}
                  onChange={(event) => setForm({ ...form, patient_id: event.target.value })}
                  required
                >
                  {patients.map((patient) => (
                    <option value={patient.id} key={patient.id}>
                      {patient.name}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Doctor
                <select
                  value={form.doctor_id}
                  onChange={(event) => setForm({ ...form, doctor_id: event.target.value })}
                  required
                >
                  {doctors.map((doctor) => (
                    <option value={doctor.id} key={doctor.id}>
                      {doctor.name} - {doctor.specialty}
                    </option>
                  ))}
                </select>
              </label>
              <div className="two-fields">
                <label>
                  Date
                  <input
                    type="date"
                    value={form.appointment_date}
                    onChange={(event) => setForm({ ...form, appointment_date: event.target.value })}
                    required
                  />
                </label>
                <label>
                  Time
                  <input
                    type="time"
                    value={form.appointment_time}
                    onChange={(event) => setForm({ ...form, appointment_time: event.target.value })}
                    required
                  />
                </label>
              </div>
              <label>
                Reason
                <textarea
                  value={form.reason}
                  onChange={(event) => setForm({ ...form, reason: event.target.value })}
                  rows="3"
                  placeholder="Fever, follow-up, consultation..."
                />
              </label>
              {bookingError && <div className="form-error">{bookingError}</div>}
              <button className="primary-button" type="submit" disabled={savingAppointment}>
                {savingAppointment ? <Loader2 className="spin" size={18} /> : <CalendarDays size={18} />}
                Save appointment
              </button>
            </form>
          )}
        </Panel>
      </section>

      <Panel
        title="Revenue report"
        icon={<Activity size={18} />}
        right={
          <div className="date-range">
            <input
              type="date"
              value={revenueRange.from}
              onChange={(event) => setRevenueRange({ ...revenueRange, from: event.target.value })}
            />
            <input
              type="date"
              value={revenueRange.to}
              onChange={(event) => setRevenueRange({ ...revenueRange, to: event.target.value })}
            />
          </div>
        }
      >
        {loading.revenue ? (
          <Spinner label="Loading revenue" />
        ) : revenue.length === 0 ? (
          <EmptyState title="No revenue for this range" text="Choose a wider date range or add invoices." />
        ) : (
          <div className="chart-box">
            <ResponsiveContainer width="100%" height={320}>
              <BarChart data={revenue}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="month" />
                <YAxis tickFormatter={(value) => `$${value}`} />
                <Tooltip formatter={(value) => formatMoney(value)} />
                <Legend />
                <Bar dataKey="invoice_total" name="Invoice" fill="#2563eb" radius={[5, 5, 0, 0]} />
                <Bar dataKey="paid_total" name="Paid" fill="#16a34a" radius={[5, 5, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </Panel>
    </main>
  );
}

function MetricCard({ title, value, subtext, icon, loading, empty }) {
  return (
    <article className="metric-card">
      <div className="metric-icon">{icon}</div>
      <div>
        <p>{title}</p>
        {loading ? <Loader2 className="spin" size={22} /> : empty ? <strong>Empty</strong> : <strong>{value}</strong>}
        {subtext && <span>{subtext}</span>}
      </div>
    </article>
  );
}

function Panel({ title, icon, right, children }) {
  return (
    <section className="panel">
      <div className="panel-header">
        <h2>
          {icon}
          {title}
        </h2>
        {right}
      </div>
      {children}
    </section>
  );
}

function SearchBox({ value, onChange }) {
  return (
    <label className="search-box">
      <Search size={16} />
      <input
        type="search"
        value={value}
        placeholder="Search patient"
        onChange={(event) => onChange(event.target.value)}
      />
    </label>
  );
}

function SortableTh({ label, column, sort, onSort }) {
  const active = sort.key === column;
  return (
    <th>
      <button className="sort-button" type="button" onClick={() => onSort(column)}>
        {label}
        {active && (sort.direction === "asc" ? <ChevronUp size={14} /> : <ChevronDown size={14} />)}
      </button>
    </th>
  );
}

function StatusBadge({ status }) {
  return <span className={`badge ${status}`}>{labelStatus(status)}</span>;
}

function Spinner({ label }) {
  return (
    <div className="state">
      <Loader2 className="spin" size={26} />
      <span>{label}</span>
    </div>
  );
}

function EmptyState({ title, text }) {
  return (
    <div className="state empty">
      <Stethoscope size={26} />
      <strong>{title}</strong>
      <span>{text}</span>
    </div>
  );
}

function statusSummary(statuses = {}) {
  return STATUS_OPTIONS.map((status) => `${labelStatus(status)} ${statuses[status] || 0}`).join(" | ");
}

function labelStatus(status) {
  return String(status).replace("_", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function formatMoney(value = 0) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(Number(value || 0));
}

function formatDateTime(value) {
  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "medium",
    timeStyle: "short"
  }).format(new Date(value));
}

const styles = `
* { box-sizing: border-box; }
body {
  margin: 0;
  background: #f4f7fb;
  color: #172033;
  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
}
button, input, select, textarea { font: inherit; }
.app-shell {
  width: min(1440px, calc(100% - 32px));
  margin: 0 auto;
  padding: 28px 0 40px;
}
.topbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 22px;
}
.eyebrow {
  margin: 0 0 6px;
  color: #2563eb;
  font-weight: 800;
  text-transform: uppercase;
  font-size: 12px;
  letter-spacing: 0;
}
h1, h2, p { margin: 0; }
h1 { font-size: clamp(28px, 4vw, 42px); line-height: 1.05; }
.metrics-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 14px;
  margin-bottom: 16px;
}
.metric-card, .panel {
  background: #ffffff;
  border: 1px solid #dce4ef;
  border-radius: 8px;
  box-shadow: 0 12px 30px rgba(17, 24, 39, 0.06);
}
.metric-card {
  min-height: 132px;
  padding: 18px;
  display: flex;
  align-items: flex-start;
  gap: 14px;
}
.metric-card p { color: #5b667a; font-weight: 700; font-size: 14px; }
.metric-card strong { display: block; margin-top: 8px; font-size: 30px; line-height: 1; }
.metric-card span { display: block; margin-top: 8px; color: #667085; font-size: 13px; }
.metric-icon {
  width: 42px;
  height: 42px;
  display: grid;
  place-items: center;
  color: #ffffff;
  background: #0f766e;
  border-radius: 8px;
  flex: 0 0 auto;
}
.work-grid {
  display: grid;
  grid-template-columns: minmax(0, 1.7fr) minmax(320px, 0.8fr);
  gap: 16px;
  align-items: start;
  margin-bottom: 16px;
}
.panel { padding: 18px; }
.panel-header {
  min-height: 42px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  margin-bottom: 14px;
}
.panel-header h2 {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 19px;
}
.alert, .form-error {
  background: #fef2f2;
  border: 1px solid #fecaca;
  color: #991b1b;
  border-radius: 8px;
  padding: 12px 14px;
  margin-bottom: 14px;
  font-weight: 700;
}
.table-wrap { overflow-x: auto; }
table { width: 100%; border-collapse: collapse; min-width: 760px; }
th, td {
  text-align: left;
  border-bottom: 1px solid #e6edf5;
  padding: 12px 10px;
  vertical-align: middle;
}
th { color: #5b667a; font-size: 13px; }
td span { display: block; color: #667085; font-size: 12px; margin-top: 3px; }
.sort-button, .icon-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  border: 0;
  background: transparent;
  color: inherit;
  cursor: pointer;
}
.icon-button {
  width: 40px;
  height: 40px;
  border: 1px solid #cfd8e5;
  border-radius: 8px;
  background: #fff;
}
.icon-button:disabled, .primary-button:disabled, select:disabled { opacity: 0.55; cursor: not-allowed; }
select, input, textarea {
  width: 100%;
  border: 1px solid #cfd8e5;
  border-radius: 8px;
  padding: 10px 12px;
  background: #ffffff;
  color: #172033;
}
textarea { resize: vertical; }
.badge {
  display: inline-flex;
  min-width: 96px;
  justify-content: center;
  padding: 6px 9px;
  border-radius: 999px;
  font-weight: 800;
  font-size: 12px;
}
.scheduled { color: #1d4ed8; background: #dbeafe; }
.checked_in { color: #92400e; background: #fef3c7; }
.completed { color: #166534; background: #dcfce7; }
.cancelled { color: #991b1b; background: #fee2e2; }
.search-box {
  width: min(270px, 100%);
  display: flex;
  align-items: center;
  gap: 8px;
  border: 1px solid #cfd8e5;
  border-radius: 8px;
  padding: 0 10px;
  background: #fff;
}
.search-box input { border: 0; padding-left: 0; outline: 0; }
.pagination {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 10px;
  padding-top: 12px;
  color: #5b667a;
  font-weight: 700;
}
.booking-form { display: grid; gap: 13px; }
.booking-form label {
  display: grid;
  gap: 7px;
  color: #4b5563;
  font-weight: 800;
  font-size: 13px;
}
.two-fields {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
}
.primary-button {
  height: 44px;
  border: 0;
  border-radius: 8px;
  background: #2563eb;
  color: #ffffff;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  cursor: pointer;
  font-weight: 800;
}
.date-range {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
  width: min(360px, 100%);
}
.chart-box { height: 340px; }
.state {
  min-height: 220px;
  display: grid;
  place-items: center;
  align-content: center;
  gap: 8px;
  color: #667085;
  text-align: center;
}
.state strong { color: #172033; }
.spin { animation: spin 0.9s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
@media (max-width: 1000px) {
  .metrics-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .work-grid { grid-template-columns: 1fr; }
}
@media (max-width: 640px) {
  .app-shell { width: min(100% - 20px, 1440px); padding-top: 16px; }
  .topbar, .panel-header { align-items: stretch; flex-direction: column; }
  .metrics-grid { grid-template-columns: 1fr; }
  .two-fields, .date-range { grid-template-columns: 1fr; }
  .search-box { width: 100%; }
}
`;

createRoot(document.getElementById("root")).render(<App />);
